let QINIU  = {};
QINIU.accessKey = 'CQWKpq1EcpSAOvKbgbu4f_OqlQlg48yNl4qMshW4';
QINIU.secretKey = 'eReCfLORrVRR8YUNI5HnH0hcZYqv0BkmVBXPSPMr';
QINIU.bucket = 'dignity';  //存储空间的名字
QINIU.origin = 'zhengzemin.cn';  //配置的域名
module.exports = QINIU;