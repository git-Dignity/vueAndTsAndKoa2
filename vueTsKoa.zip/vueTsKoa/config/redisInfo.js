// 配置redis基本信息

module.exports  = {
    RDS_PORT:6379,  // 端口
    RDS_HOST:'127.0.0.1',   // 此端口为80 
    RDS_PASS:'zhengzemin',  //redis连接密码
    RDS_DBNUM:'1'  // 库号
}




