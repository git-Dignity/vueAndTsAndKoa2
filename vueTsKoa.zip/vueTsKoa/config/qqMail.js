module.exports = {
    pass: "oslmttomzifmiaec"  //qq邮箱授权码
};