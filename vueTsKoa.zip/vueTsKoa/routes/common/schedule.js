var schedule = require('node-schedule');

/**
 * 在指定时间执行方法
 * @param {Date} date new Date(2017, 11, 16, 16, 43, 0);
 * @param {Function} callback 回调函数
 * ege: 2014年2月14日，15:40执行
 */
const specifiedTime = (date, callback) =>{
    return schedule.scheduleJob(date, function(){
        callback()
    });
}


// 代做
// 指定时间间隔
// 每什么执行一次 
// 只能传一个参数
// 支持 second,minute,hour,date,dayOfWeek,month,year 要传两个参数，一个是数字，一个是标记类型
const specifyTimeInterval = (num, type) =>{

}



module.exports = {
    specifiedTime,
    specifyTimeInterval
}



// https://blog.csdn.net/ffzhihua/article/details/81564107?utm_medium=distribute.pc_relevant.none-task-blog-title-2&spm=1001.2101.3001.4242